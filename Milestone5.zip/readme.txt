Run instructions:

navigate to “java” folder and once inside the folder run the following command:

java RunEdgeConvert

The rest of the instructions are in the Help menu.
Great success!